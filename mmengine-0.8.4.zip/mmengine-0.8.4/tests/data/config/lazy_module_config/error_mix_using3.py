# Copyright (c) OpenMMLab. All rights reserved.
import numpy as np
