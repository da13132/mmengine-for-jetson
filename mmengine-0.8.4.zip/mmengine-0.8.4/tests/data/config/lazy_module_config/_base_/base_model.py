# Copyright (c) OpenMMLab. All rights reserved.
from mmengine.testing.runner_test_case import ToyModel

model = dict(type=ToyModel)
