# Copyright (c) OpenMMLab. All rights reserved.
item1 = 1


def get_item2():
    return item1 + 1


item2 = get_item2()
