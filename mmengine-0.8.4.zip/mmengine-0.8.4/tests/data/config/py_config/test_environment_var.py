# Copyright (c) OpenMMLab. All rights reserved.
item1 = '{{ $ITEM1: }}'
item2 = '{{ $ITEM2:default_value }}'
item3 = {{' $ITEM3:80 '}}
