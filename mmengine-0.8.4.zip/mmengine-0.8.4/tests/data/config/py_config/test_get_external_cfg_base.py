# Copyright (c) OpenMMLab. All rights reserved.
toy_model = dict(type='ToyModel')
