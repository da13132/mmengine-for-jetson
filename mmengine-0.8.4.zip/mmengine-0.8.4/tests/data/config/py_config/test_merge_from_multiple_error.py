# Copyright (c) OpenMMLab. All rights reserved.
_base_ = [
    './base1.py', '../yaml_config/base2.yaml', '../json_config/base3.json',
    'simple_config.py'
]
item3 = False
item4 = 'test'
