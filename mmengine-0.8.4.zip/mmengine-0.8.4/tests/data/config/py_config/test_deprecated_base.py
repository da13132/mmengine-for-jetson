# Copyright (c) OpenMMLab. All rights reserved.
_base_ = './test_deprecated.py'
