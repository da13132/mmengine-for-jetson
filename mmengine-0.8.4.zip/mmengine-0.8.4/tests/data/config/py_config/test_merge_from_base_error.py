# Copyright (c) OpenMMLab. All rights reserved.
_base_ = './base.py'
item3 = {'a': 1}
