# Copyright (c) OpenMMLab. All rights reserved.
_base_ = './base.py'
item1 = {'a': 0, '_delete_': True}
item2 = {'b': 0}
