# Copyright (c) OpenMMLab. All rights reserved.
custom_imports = dict(
    imports=['test_custom_import_module'], allow_failed_imports=False)
