# Copyright (c) OpenMMLab. All rights reserved.
_base_ = './base.py'

_deprecation_ = dict(
    expected='tests/data/config/py_config/base.py', reference='')
