# Copyright (c) OpenMMLab. All rights reserved.
a = 1
b = 2
