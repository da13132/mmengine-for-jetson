# Copyright (c) OpenMMLab. All rights reserved.
from .distributed import MultiProcessTestCase

__all__ = ['MultiProcessTestCase']
