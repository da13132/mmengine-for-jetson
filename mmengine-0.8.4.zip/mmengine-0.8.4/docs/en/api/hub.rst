.. role:: hidden
    :class: hidden-section

mmengine.hub
===================================

.. currentmodule:: mmengine.hub

.. autosummary::
   :toctree: generated
   :nosignatures:

   get_config
   get_model
