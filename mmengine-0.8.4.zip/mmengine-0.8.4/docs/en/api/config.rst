.. role:: hidden
    :class: hidden-section

mmengine.config
===================================

.. currentmodule:: mmengine.config

.. autosummary::
   :toctree: generated
   :nosignatures:
   :template: classtemplate.rst

   Config
   ConfigDict
   DictAction
   read_base
