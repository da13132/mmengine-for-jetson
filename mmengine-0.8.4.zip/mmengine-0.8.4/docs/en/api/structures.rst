.. role:: hidden
    :class: hidden-section

mmengine.structures
===================================

.. contents:: mmengine.structures
   :depth: 2
   :local:
   :backlinks: top

.. currentmodule:: mmengine.structures

.. autosummary::
   :toctree: generated
   :nosignatures:
   :template: classtemplate.rst

    BaseDataElement
    InstanceData
    LabelData
    PixelData
