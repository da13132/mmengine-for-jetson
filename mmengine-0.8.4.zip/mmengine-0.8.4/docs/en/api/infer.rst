.. role:: hidden
    :class: hidden-section

mmengine.infer
===================================

.. currentmodule:: mmengine.infer

.. autosummary::
   :toctree: generated
   :nosignatures:
   :template: classtemplate.rst

   BaseInferencer
