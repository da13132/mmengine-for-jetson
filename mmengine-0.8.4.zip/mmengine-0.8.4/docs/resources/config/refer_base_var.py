_base_ = ['resnet50.py']
a = {{_base_.model}}
