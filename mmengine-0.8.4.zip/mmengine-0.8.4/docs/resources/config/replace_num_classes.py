model = dict(bbox_head=dict(num_classes={{'$NUM_CLASSES:80'}}))
