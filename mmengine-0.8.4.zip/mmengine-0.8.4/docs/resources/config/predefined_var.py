work_dir = './work_dir/{{fileBasenameNoExtension}}'
