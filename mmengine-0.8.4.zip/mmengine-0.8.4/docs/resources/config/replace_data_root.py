dataset_type = 'CocoDataset'
data_root = '{{$DATASET:/data/coco/}}'
dataset = dict(ann_file=data_root + 'train.json')
